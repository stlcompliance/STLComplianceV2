# MaintainArr Granular End-Goal Markdown Package

This package defines MaintainArr at the domain-object level.

## Files

- `maintainarr_00_scope_and_boundaries.md`
- `maintainarr_01_asset_and_component_model.md`
- `maintainarr_02_work_order_model.md`
- `maintainarr_03_defect_inspection_pm_model.md`
- `maintainarr_04_parts_labor_downtime_vendor_model.md`
- `maintainarr_05_workflows_status_events_apis.md`

## Purpose

MaintainArr owns the maintenance execution system for STL Compliance / ARR:

- Assets
- Components
- Asset readiness
- Preventive maintenance
- Inspections
- Defects
- Work orders
- Maintenance tasks
- Labor
- Parts demand
- Parts usage/installation
- Downtime
- Vendor maintenance coordination
- Maintenance closeout
- Maintenance audit trail

MaintainArr does not own inventory truth, procurement truth, people truth, training truth, document storage truth, or regulatory meaning.
